/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.Controller;

import java.io.IOException; 
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.Person;
import za.ac.tut.model.PersonFacadeLocal;

/**
 *
 * @author Desmond
 */
public class AddPersonServlet extends HttpServlet {
@EJB
private PersonFacadeLocal pfl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
             String name=request.getParameter("name");
             String surname=request.getParameter("surname");
             String race=request.getParameter("race");
             String gender=request.getParameter("gender");
             String dob=request.getParameter("dob");
             Date dateOfBirth=null;
             
             SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
    try {
        dateOfBirth=format.parse(dob);
    } catch (ParseException ex) {
        Logger.getLogger(AddPersonServlet.class.getName()).log(Level.SEVERE, null, ex);
    }
         
    Person person=new Person(name, surname, race, gender, dateOfBirth, new Date(System.currentTimeMillis()));
    pfl.create(person);
    
    request.getRequestDispatcher("AddSuccess.html").forward(request, response);
    
    }

}
