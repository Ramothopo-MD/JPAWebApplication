/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.Person;
import za.ac.tut.model.PersonFacadeLocal;

/**
 *
 * @author Desmond
 */
public class searchPersonServlet extends HttpServlet {

   @EJB
   private PersonFacadeLocal pfl;

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
           
            try {
             Long id=Long.parseLong(request.getParameter("id"));
             Person person=pfl.find(id);
                if (person!=null) {
                    request.setAttribute("person", person);
                    request.getRequestDispatcher("ResultPage.jsp").forward(request, response);
                }
        } catch (NumberFormatException e){
            request.getRequestDispatcher("ErrorPage.html").forward(request, response);
            
        }catch(NullPointerException n){
        request.getRequestDispatcher("ErrorPage.html").forward(request, response);
        }
            
            
    }


}
